
// Scroll progress
window.addEventListener('scroll', () => {
  const doc = document.documentElement;
  const scrolled = (doc.scrollTop / (doc.scrollHeight - doc.clientHeight)) * 100;
  document.getElementById('scroll-progress').style.width = scrolled + '%';
});

// Skeleton removal
window.addEventListener('load', () => {
  document.querySelectorAll('.skeleton').forEach(el => {
    el.classList.remove('skeleton');
  });
});
